<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
// The contents of this file has been removed in favour of the classes/class-wf-screen-framework.php file.
?>