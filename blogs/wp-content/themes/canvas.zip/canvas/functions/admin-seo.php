<?php
// File Security Check.
if ( ! defined( 'ABSPATH' ) ) exit;
// WooSEO removed as of WooFramework version 5.5.0.
?>